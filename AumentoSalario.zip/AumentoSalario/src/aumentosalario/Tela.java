package aumentosalario;

/**
 *
 * @author Gabriella
 */
public class Tela extends javax.swing.JFrame {

    public Tela() {
        initComponents();
        //deixando invisível as labels abaixo quando a tela for executada:
        lblMensagem.setVisible(false);
        lblMensagem1.setVisible(false);
        lblResultadoNomeF.setVisible(false);
        lblResultadoSal.setVisible(false);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblTitulo = new javax.swing.JLabel();
        lblSalario = new javax.swing.JLabel();
        txtSalario = new javax.swing.JTextField();
        btnCalcular = new javax.swing.JButton();
        lblResultadoSal = new javax.swing.JLabel();
        lblMensagem = new javax.swing.JLabel();
        lblNomeFunc = new javax.swing.JLabel();
        txtNomeFunc = new javax.swing.JTextField();
        lblMensagem1 = new javax.swing.JLabel();
        lblResultadoNomeF = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        setName("tela"); // NOI18N
        setResizable(false);

        lblTitulo.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblTitulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitulo.setText("Calculadora de aumento de salário");

        lblSalario.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblSalario.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblSalario.setText("Salário do funcionário:");

        txtSalario.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txtSalario.setForeground(new java.awt.Color(153, 153, 153));
        txtSalario.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtSalario.setBorder(null);
        txtSalario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtSalarioActionPerformed(evt);
            }
        });

        btnCalcular.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        btnCalcular.setText("Calcular");
        btnCalcular.setBorder(null);
        btnCalcular.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCalcularActionPerformed(evt);
            }
        });

        lblResultadoSal.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblResultadoSal.setForeground(new java.awt.Color(73, 160, 120));
        lblResultadoSal.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblResultadoSal.setText("R$");

        lblMensagem.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblMensagem.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblMensagem.setText("Novo salário:");

        lblNomeFunc.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblNomeFunc.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblNomeFunc.setText("Nome do funcionário:");

        txtNomeFunc.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        txtNomeFunc.setForeground(new java.awt.Color(153, 153, 153));
        txtNomeFunc.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtNomeFunc.setBorder(null);
        txtNomeFunc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeFuncActionPerformed(evt);
            }
        });

        lblMensagem1.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblMensagem1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblMensagem1.setText("Nome do funcionário:");

        lblResultadoNomeF.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        lblResultadoNomeF.setForeground(new java.awt.Color(73, 160, 120));
        lblResultadoNomeF.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        lblResultadoNomeF.setText("nome");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(83, 83, 83)
                        .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 279, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblMensagem1, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblMensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(58, 58, 58)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblResultadoNomeF, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblResultadoSal, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblSalario)
                                    .addComponent(lblNomeFunc))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNomeFunc, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE)
                                    .addComponent(txtSalario))))))
                .addContainerGap(54, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(lblTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblNomeFunc)
                    .addComponent(txtNomeFunc, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSalario)
                    .addComponent(txtSalario, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addComponent(btnCalcular, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblResultadoNomeF, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblMensagem1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblMensagem, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblResultadoSal, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(37, 37, 37))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtSalarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtSalarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtSalarioActionPerformed

    private void btnCalcularActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCalcularActionPerformed
        //pegando o que tá na txtSalario e convertendo pra int (isso porque txt é String)
        double sal = Double.parseDouble(txtSalario.getText().toString());
        
        //pegando o que tá na txtNomeFunc e atribuindo a informação a uma variável:
        String n = txtNomeFunc.getText();
        
        //passando o que tá na variável n pra label lblResultadoNomeF:
        lblResultadoNomeF.setText(n);
        
        double r, acrescimo;
        
        //analisando se o salário é menor ou maior que R$ 2.000,00 e quais acréscimos receberá
        if (sal >= 2000.00){
            r = sal * 0.02;
            acrescimo = r + sal;
            
            //passando o salário com o novo acréscimo pra label lblResultado:
            lblResultadoSal.setText(String.format("R$ %.2f", acrescimo));
            
            //ativando a visibilidade das labels:
            lblMensagem.setVisible(true);
            lblMensagem1.setVisible(true);
            lblResultadoNomeF.setVisible(true);
            lblResultadoSal.setVisible(true);
        }
        else{
            r = sal * 0.10;
            acrescimo = r + sal;
            
            //passando o salário com o novo acréscimo pra label lblResultado:
            lblResultadoSal.setText(String.format("R$ %.2f", acrescimo));
            
            //ativando a visibilidade das labels:
            lblMensagem.setVisible(true);
            lblMensagem1.setVisible(true);
            lblResultadoNomeF.setVisible(true);
            lblResultadoSal.setVisible(true);
        }
    }//GEN-LAST:event_btnCalcularActionPerformed

    private void txtNomeFuncActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeFuncActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeFuncActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Tela.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Tela().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCalcular;
    private javax.swing.JLabel lblMensagem;
    private javax.swing.JLabel lblMensagem1;
    private javax.swing.JLabel lblNomeFunc;
    private javax.swing.JLabel lblResultadoNomeF;
    private javax.swing.JLabel lblResultadoSal;
    private javax.swing.JLabel lblSalario;
    private javax.swing.JLabel lblTitulo;
    private javax.swing.JTextField txtNomeFunc;
    private javax.swing.JTextField txtSalario;
    // End of variables declaration//GEN-END:variables
}
